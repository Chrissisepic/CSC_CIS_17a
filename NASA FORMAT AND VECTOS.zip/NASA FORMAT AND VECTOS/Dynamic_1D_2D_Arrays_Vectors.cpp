#include <iostream>
#include <vector>
using namespace std;

vector<int> getData() {
    int n;
    cin >> n;
    vector<int> arr(n);
    for (int i = 0; i < n; i++) cin >> arr[i];
    return arr;
}

vector<int> sumAry(const vector<int> &arr) {
    int n = arr.size();
    vector<int> sum(n);
    sum[0] = arr[0];
    for (int i = 1; i < n; i++) {
        sum[i] = sum[i - 1] + arr[i];
    }
    return sum;
}

void prntAry(const vector<int> &arr) {
    for (int i = 0; i < arr.size(); i++) {
        cout << arr[i];
        if (i < arr.size() - 1) cout << " ";
    }
    cout << endl;
}

int main() {
    vector<int> arr = getData();
    vector<int> sum = sumAry(arr);
    prntAry(arr);
    prntAry(sum);
    return 0;
}
